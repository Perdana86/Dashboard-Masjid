import { useCallback, useEffect, useState } from 'react';
import pb from '@/lib/pocketbaseClient';
import { fetchDashboardSlides, fetchJadwal, fetchSettings, fetchSlides, isAbortError, jakartaParts } from '@/lib/masjid';

const onlyActive = (list) => (list || []).filter((item) => item.active !== false);

export default function useMasjidData() {
    const [settings, setSettings] = useState(null);
    const [slides, setSlides] = useState([]);
    const [dashboardSlides, setDashboardSlides] = useState([]);
    const [prayer, setPrayer] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const load = useCallback(async () => {
        setError('');
        try {
            // Each call gets a distinct requestKey so concurrent mounts (e.g.
            // PWA manifest hook + this hook) don't share the SDK default key
            // and auto-cancel each other.
            const [s, sl, dsl] = await Promise.all([
                fetchSettings({ requestKey: 'masjid-data-settings' }),
                fetchSlides(),
                fetchDashboardSlides(),
            ]);
            setSettings(s);
            setSlides(onlyActive(sl));
            setDashboardSlides(onlyActive(dsl));

            const cityId = (s && s.city_id) || '1301';
            try {
                setPrayer(await fetchJadwal(cityId, jakartaParts().isoDate));
            } catch (e) {
                setPrayer(null);
                if (!isAbortError(e)) setError(e.message);
            }
        } catch (e) {
            // Abort/auto-cancel is expected when a newer load supersedes this
            // one — never surface it as a user-facing error.
            if (!isAbortError(e)) setError(e.message || 'Gagal memuat data masjid');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        load();
    }, [load]);

    // refresh schedule every 15 minutes (also handles date rollover)
    useEffect(() => {
        const id = setInterval(() => {
            load();
        }, 15 * 60 * 1000);
        return () => clearInterval(id);
    }, [load]);

    // Realtime sync: refresh slide lists whenever either collection changes.
    useEffect(() => {
        let cancelled = false;
        const subscribe = (collection, setter) =>
            pb
                .collection(collection)
                .subscribe('*', () => {
                    if (cancelled) return;
                    pb.collection(collection)
                        .getFullList({ sort: 'position,created' })
                        .then((list) => setter(onlyActive(list)))
                        .catch(() => {});
                })
                .catch(() => {});

        const p1 = subscribe('slides', setSlides);
        const p2 = subscribe('dashboard_slides', setDashboardSlides);
        const p3 = pb
            .collection('settings')
            .subscribe('*', () => {
                if (cancelled) return;
                fetchSettings({ requestKey: 'masjid-data-settings-rt' })
                    .then((s) => setSettings(s))
                    .catch(() => {});
            })
            .catch(() => {});

        return () => {
            cancelled = true;
            void p1.then((fn) => fn && fn()).catch(() => {});
            void p2.then((fn) => fn && fn()).catch(() => {});
            void p3.then((fn) => fn && fn()).catch(() => {});
            void pb.collection('slides').unsubscribe('*').catch(() => {});
            void pb.collection('dashboard_slides').unsubscribe('*').catch(() => {});
            void pb.collection('settings').unsubscribe('*').catch(() => {});
        };
    }, []);

    return { settings, slides, dashboardSlides, prayer, loading, error, reload: load };
}
